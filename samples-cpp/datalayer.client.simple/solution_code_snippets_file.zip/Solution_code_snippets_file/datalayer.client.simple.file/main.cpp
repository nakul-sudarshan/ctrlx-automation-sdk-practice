/*
 * SPDX-FileCopyrightText: Bosch Rexroth AG
 *
 * SPDX-License-Identifier: MIT
 */

#include <stdio.h>
#include <iostream>
#include <fstream>

#include "comm/datalayer/datalayer.h"
#include "comm/datalayer/datalayer_system.h"

#include <sys/stat.h>

//! Retrieve environment variable SNAP
//! @result The content of SNAP ales nullptr if not available
static const char *snapPath()
{
  return std::getenv("SNAP");
}

//! Test if code is runnning in snap environment
//! @result True if running snap environment
static bool isSnap()
{
  return snapPath() != nullptr;
}

//! Get Datalayer connection string
//! @param[in] ip       IP address of the ctrlX CORE: 10.0.2.2 is ctrlX COREvirtual with port forwarding
//! @param[in] user     User name
//! @param[in] password The password
//! @param[in] sslPort  The port number for SSL: 8443 if ctrlX COREvirtual with port forwarding 8443:443
//! @result Connection string
static std::string getConnectionString(
    const std::string &ip = "192.168.1.1",
    const std::string &user = "boschrexroth",
    const std::string &password = "boschrexroth",
    int sslPort = 443)
{
  if (isSnap())
  {
    return DL_IPC;
  }

  std::string connectionString = DL_TCP + user + std::string(":") + password + std::string("@") + ip;

  if (443 == sslPort)
  {
    return connectionString;
  }

  return connectionString + std::string("?sslport=") + std::to_string(sslPort);
}

// The enry point of the snap.
// Runs an endless loop until stopped or ctrlX Data Layer clientconnection breaks.
int main()
{

  std::cout << "INFO Starting ctrlX Data Layer system (without broker)" << std::endl;
  comm::datalayer::DatalayerSystem datalayerSystem;
  datalayerSystem.start(false);

  auto connectionString = getConnectionString("10.0.2.2","boschrexroth","boschrexroth",8443); // default: ctrlX CORE or ctrlX COREvirtual with Network Adpater
  std::cout << "INFO Creating ctrlX Data Layer client connection to " << connectionString << " ..." << std::endl;
  auto dataLayerClient = datalayerSystem.factory()->createClient(connectionString);

  if (dataLayerClient->isConnected() == false)
  {
    delete dataLayerClient;

    auto connectionString2 = getConnectionString("10.0.2.2", "boschrexroth", "boschrexroth", 8443); // ctrlX COREvirtual with Port Forwarding
    std::cout << "WARNING Cannot connect to " << connectionString << " trying " << connectionString2 << std::endl;

    auto dataLayerClient = datalayerSystem.factory()->createClient(connectionString2);
  }


  // Path to the directory
  const char* dir = "/var/snap/simple-client-file/common/solutions/activeConfiguration";
  // Path to folder
  const char* folderpath = "/var/snap/simple-client-file/common/solutions/activeConfiguration/simple-client-file";
 
  // Structure which would store the metadata
  struct stat sb;
 
  // If the file/directory exists at the path returns 0
  // Wait until the directory is present
  while(stat(dir, &sb) != 0){
    std::cout << "Waiting for the directory to be present" <<std::endl;
    sleep(2);
  }
    std::cout << "Success! The directory is present" << std::endl;


  //Create a folder
  int status = mkdir(folderpath,0777);
  // Create and open a text file
  std::string filepath = "/var/snap/simple-client-file/common/solutions/activeConfiguration/simple-client-file/loggingCPU.txt";
  std::ofstream MyFile(filepath);
  //std::ofstream MyFile("$SNAP_COMMON/solutions/activeConfiguration/simple-client-file/loggingCPU.txt");


  int counter = 1;
  while (dataLayerClient->isConnected())
  {
    std::cout << "Loop #" << counter++ << std::endl;

    if (counter > 100){
      //deleting the file after 100 lines and creating a new one
      MyFile.close();
      remove (filepath.c_str());
      MyFile.open(filepath);
      counter = 1;
    }

    // Synchronous read of a ctrlX Data Layer node with a simple data type -----------------------------------------------------------
    auto cpuUtilisationPercentAddress = "framework/metrics/system/cpu-utilisation-percent";
    comm::datalayer::Variant cpuUtilisationPercentValue;
    std::cout << "INFO Reading " << cpuUtilisationPercentAddress << " synchronously..." << std::endl;
    auto result = dataLayerClient->readSync(cpuUtilisationPercentAddress, &cpuUtilisationPercentValue);
    if (result != DL_OK)
    {
      std::cout << "WARN Reading " << cpuUtilisationPercentAddress << " failed with: " << result.toString() << std::endl;
    }
    else
    {
      if (cpuUtilisationPercentValue.getType() == comm::datalayer::VariantType::FLOAT64)
      {
        std::cout << "INFO Value of " << cpuUtilisationPercentAddress << ": " << double(cpuUtilisationPercentValue) << " %" << std::endl;
        MyFile << "CPU Value: " << double(cpuUtilisationPercentValue)<<std::endl;
      }
      else
      {
        std::cout << "WARN Value of " << cpuUtilisationPercentAddress << " has unexpected type: " << cpuUtilisationPercentValue.typeAsString() << std::endl;
      }
    }



    std::cout << "INFO Sleeping..." << std::endl;
    sleep(2);
  }

  std::cout << "ERROR ctrlX Data Layer connection is broken" << std::endl;

  MyFile.close();

  delete dataLayerClient;
  datalayerSystem.stop();

  return 1; // We exit because an error happend
}
