# README datalayer.client.simple

## Introduction

This app will read the cpu utilisation from ctrlX Data Layer print the value to the console.
Additionally the cpu utilisation is also logged in a file in the active configuration (simple-client-file/loggingCPU.txt).


## Prerequisite

A running ctrlX WORKS App Build Environment like described [here](https://boschrexroth.github.io/ctrlx-automation-sdk/setup_qemu_ctrlx_works.html)

## Function Description

The app demonstrates how values of the ctrlX Data Layer nodes can be read. And how a file can be created in the Active Configuration on the ctrlX OS.

## Implementation Description

In main.cpp the ctrlX Data Layer system is started and a client connection is established.

After that the execution waits until the active Configuration is present. (This is the case when the interface "acitve-solution" is connected.)

Then an endless loop is running:

* The cpu utilisation is read from the ctrlX Data Layer and printed to the console.
* The cpu utilisation is also logged into a file in the the active configuration (simple-client-file/loggingCPU.txt).
* After a sleep of 2 seconds the loop is repeated.

The loop ends and the main method exits when the ctrlX Data Layer client connection was broken.

With the help of the entry 'restart-condition: always' in snapcraft.yaml the snap is automatically restarted.


## Build and Install the Snap

Build and install the snap like described [here](../README.md).

## See the file in the ctrlX OS Web-UI
![activeConfiguration](./doc/images/folder-in-active-configuration.png)
![logFile](./doc/images/loggingCPU-file.png)


## Test the Snap running on a ctrlX CORE

__ Only if SSH access is available!__

* Install the snap
* Open a SSH connection to your ctrlX CORE
* Check trace output: `sudo snap logs -f sdk-cpp-client-simple`

___

## License

SPDX-FileCopyrightText: Bosch Rexroth AG
SPDX-License-Identifier: MIT
